<?php
/**
 * Deprecated. See notes.php for the new module
 *
 * @package Jetpack
 **/
