Yoast API libraries (Libs)
==========================