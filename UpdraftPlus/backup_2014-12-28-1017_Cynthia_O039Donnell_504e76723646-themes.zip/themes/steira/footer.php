			<div id="footer">

				<p id="generator">
					<a href="http://wordpress.org/" rel="generator">Proudly powered by WordPress</a>
				</p>

				<p id="credits">
					<?php printf( __( 'Theme: %1$s by %2$s.', 'steira' ), 'Steira', '<a href="http://www.madebyelephant.com/" rel="designer">Made by Elephant</a>' ); ?>
				</p>

			</div><!-- footer -->

		</div><!-- wrapper -->

<?php wp_footer(); ?>
	</body>

</html>