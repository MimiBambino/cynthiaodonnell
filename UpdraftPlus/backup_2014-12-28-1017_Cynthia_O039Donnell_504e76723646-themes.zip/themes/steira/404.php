<?php get_header(); ?>

			<div id="body">

				<div id="content">

					<div class="hentry post" id="post-0">

						<h2><?php _e('Not Found', 'steira'); ?></h2>

						<div class="contentblock">

							<p><?php _e('Sorry, but you are looking for something that isn&rsquo;t here.', 'steira'); ?></p>

							<?php get_search_form(); ?>

						</div><!-- content-block -->

					</div><!-- #post-0 -->

				</div><!-- content -->

<?php get_sidebar(); ?>

			</div><!-- body -->

<?php get_footer(); ?>