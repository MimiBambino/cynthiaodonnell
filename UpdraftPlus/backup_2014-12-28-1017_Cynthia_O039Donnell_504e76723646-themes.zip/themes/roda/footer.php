<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Roda
 */
?>

	</div><!-- #content -->
	<div class="footer-separator">  
		<?php echo roda_footer_svg(); ?>
	</div>
	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="site-info container">
                  <p>© Cynthia O'Donnell <?php echo date("Y") ?></p>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
